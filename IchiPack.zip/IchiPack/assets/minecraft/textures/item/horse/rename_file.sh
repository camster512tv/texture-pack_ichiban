#!/bin/bash

# Directory containing the files to rename
directory="C:\Users\Florian\AppData\Roaming\.minecraft\resourcepacks\Ichiban_pack\assets\minecraft\textures\item\horse"

# Loop through each file in the directory starting from the highest number
for (( i=34; i>=0; i-- ))
do
  # Construct current and new file names
  current_file="$directory/$i.png"
  new_file="$directory/$(($i + 1)).png"

  # Check if the current file exists before renaming
  if [ -e "$current_file" ]; then
    mv "$current_file" "$new_file"
    echo "Renamed $current_file to $new_file"
  else
    echo "File $current_file not found."
  fi
done